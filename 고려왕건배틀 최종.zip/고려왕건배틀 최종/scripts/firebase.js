/* ══════════════════════════════════════
   왕건의 통일 배틀 — Firebase 실시간 경쟁 모듈
   v2.0.13: Firebase 설정·초기화·세션 구독 분리
══════════════════════════════════════ */
(function initGameFirebase(global) {
  'use strict';

  const FIREBASE_ENABLED = true; // ✅ Firebase 활성화됨

  const FIREBASE_CONFIG = {
    apiKey:            "AIzaSyDurZBuNiNz9rfT5A26gtXGiVNRklh0eVE",
    authDomain:        "gorey-wangon.firebaseapp.com",
    databaseURL:       "https://gorey-wangon-default-rtdb.firebaseio.com",
    projectId:         "gorey-wangon",
    storageBucket:     "gorey-wangon.firebasestorage.app",
    messagingSenderId: "489022134050",
    appId:             "1:489022134050:web:a89f8d522c8207f7b1777b"
  };

  const SDK_VERSION = '10.12.0';
  const state = {
    ready: false,
    db: null,
    ref: null,
    set: null,
    onValue: null,
    remove: null,
    serverTimestamp: null,
    playersUnsub: null,
    sessionEndUnsub: null,
    pollTimer: null
  };

  function isReady() {
    return !!(state.db && state.ready);
  }

  function getSessionKey(date = new Date()) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  function sessionRef(path) {
    if (!isReady()) return null;
    return state.ref(state.db, `sessions/${getSessionKey()}/${path}`);
  }

  async function init() {
    if (!FIREBASE_ENABLED) return false;
    if (isReady()) return true;
    try {
      const [appMod, dbMod] = await Promise.all([
        import(`https://www.gstatic.com/firebasejs/${SDK_VERSION}/firebase-app.js`),
        import(`https://www.gstatic.com/firebasejs/${SDK_VERSION}/firebase-database.js`)
      ]);
      const { initializeApp, getApps, getApp } = appMod;
      const { getDatabase, ref, set, onValue, remove, serverTimestamp } = dbMod;

      const app = getApps().length > 0 ? getApp() : initializeApp(FIREBASE_CONFIG);
      const db = getDatabase(app);

      state.db = db;
      state.ref = ref;
      state.set = set;
      state.onValue = onValue;
      state.remove = remove;
      state.serverTimestamp = serverTimestamp;
      state.ready = true;

      // 하위 호환용 전역 참조 유지
      global._fbDb = db;
      global._fbRef = ref;
      global._fbSet = set;
      global._fbOnValue = onValue;
      global._fbRemove = remove;
      global._fbServerTs = serverTimestamp;
      global._fbReady = true;

      if (global.document && typeof global.Event === 'function') {
        global.document.dispatchEvent(new Event('fb-ready'));
      }
      return true;
    } catch (e) {
      state.ready = false;
      global._fbReady = false;
      console.warn('Firebase 연결 실패:', e && e.message ? e.message : e);
      return false;
    }
  }

  async function savePlayerScore(playerId, payload) {
    if (!isReady() || !playerId) return false;
    const record = {
      ...payload,
      updatedAt: state.serverTimestamp()
    };
    await state.set(sessionRef(`players/${playerId}`), record);
    return true;
  }

  async function removePlayers() {
    if (!isReady()) return false;
    await state.remove(sessionRef('players'));
    return true;
  }

  async function resetSession() {
    if (!isReady()) return false;
    await state.remove(sessionRef('players'));
    await state.remove(sessionRef('session_ended'));
    return true;
  }

  async function endSession(endedBy = 'teacher') {
    if (!isReady()) return false;
    await state.set(sessionRef('session_ended'), {
      endedAt: Date.now(),
      endedBy
    });
    return true;
  }

  function subscribePlayers(onChange) {
    unsubscribePlayers();
    if (!isReady()) return null;
    state.playersUnsub = state.onValue(sessionRef('players'), (snapshot) => {
      const data = snapshot && typeof snapshot.val === 'function'
        ? (snapshot.val() || {})
        : {};
      if (typeof onChange === 'function') onChange(data);
    });
    return state.playersUnsub;
  }

  function unsubscribePlayers() {
    if (state.playersUnsub) {
      try { state.playersUnsub(); } catch (e) {}
      state.playersUnsub = null;
    }
    if (state.pollTimer) {
      clearInterval(state.pollTimer);
      state.pollTimer = null;
    }
  }

  function watchSessionEnd(onEnded) {
    stopSessionEndWatch();
    if (!isReady()) return null;
    try {
      const endRef = sessionRef('session_ended');
      // 구독 시작 시각 기록 — 이보다 이전에 기록된 종료 신호는 무시
      const watchStartTime = Date.now();
      state.sessionEndUnsub = state.onValue(endRef, (snapshot) => {
        const val = snapshot && typeof snapshot.val === 'function' ? snapshot.val() : null;
        if (!val) return;
        const endedAt = val.endedAt || 0;
        const isNewSignal = (typeof endedAt === 'number')
          ? endedAt > watchStartTime - 5000
          : false;
        if (!isNewSignal) return;
        if (typeof onEnded === 'function') onEnded(val);
      });
      return state.sessionEndUnsub;
    } catch (e) {
      console.warn('watchSessionEnd 오류:', e);
      return null;
    }
  }

  function stopSessionEndWatch() {
    if (state.sessionEndUnsub) {
      try { state.sessionEndUnsub(); } catch (e) {}
      state.sessionEndUnsub = null;
    }
  }

  function stopAllSubscriptions() {
    unsubscribePlayers();
    stopSessionEndWatch();
  }

  global.GAME_FIREBASE = Object.freeze({
    ENABLED: FIREBASE_ENABLED,
    CONFIG: Object.freeze({ ...FIREBASE_CONFIG }),
    init,
    isReady,
    getSessionKey,
    sessionRef,
    savePlayerScore,
    removePlayers,
    resetSession,
    endSession,
    subscribePlayers,
    unsubscribePlayers,
    watchSessionEnd,
    stopSessionEndWatch,
    stopAllSubscriptions
  });
})(window);
